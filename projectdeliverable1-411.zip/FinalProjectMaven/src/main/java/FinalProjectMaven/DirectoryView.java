/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FinalProjectMaven;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *
 * @author dukei
 */
public class DirectoryView extends View {

    Path files;
    int status = 0;

    public DirectoryView(String directory) {
        if (directory.equals("/")) {
            directory = "/index.html";
        }
        if (directory.equals("")) {
            directory = "/index.html";
        }
        files = Paths.get("public" + directory);
        if (Files.exists(files)) {
        } else {
            status = -1;
        }
    }


    public boolean isOKStatus() {

        return (status == 0);
    }

    //overrides view
    @Override
    public String makeHTML() {

        try {
            return new String(Files.readAllBytes(files), StandardCharsets.UTF_8);
        } catch (IOException ex) {
            return "Error with File";

        }

    }

}
