/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FinalProjectMaven;

public class TransactionController {


    public TransactionController() {
    }

    public View respondToLocationRequest(HttpRequest request) {
        View view = null;   
        if (request.location.equals("/home")) {
            if (request.params.isEmpty()) {
                view = new MainView();
            } else {
                TransactionModel tm = new TransactionModel();

             
                try {
             
                } catch (java.lang.NumberFormatException e) {
                    
                }
         

                if (tm.isValid()) {
                   
                  
                } else {
                    view = new MainView();
                }
            }
        }  else if (request.location.equals("/account")) 
        {
            view = new Accountinfoview();
         
        }
        else if(request.location.equals("/transfer")){
            view = new TransactionView();
        //transfer view here
        }
        else if (request.location.equals("/balance")){
            view = new AccountBalanceView();
            //balance view
        }
        else if(request.location.equals("/login")){
            view = new LoginView();
            //login view
        }
        else {
       view = new DirectoryView(request.location);
            if (! view.isOKStatus())
                view = new NotFoundView();

        }

        return view;
    }

}
