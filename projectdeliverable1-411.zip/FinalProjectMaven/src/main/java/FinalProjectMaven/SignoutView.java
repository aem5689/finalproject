/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FinalProjectMaven;

/**
 *
 * @author dukei
 */
public class SignoutView  extends View {

    public SignoutView() {
       
    }
    
    @Override
    public String makeHTML() {

        String html = "<html><body>";

        html += "Thank you, (Name here)!";
        html += "<button type=\"button\">Return to Login</button><br>";
        
        html += "</body></html>";

        return html;
        
    }
    
}
