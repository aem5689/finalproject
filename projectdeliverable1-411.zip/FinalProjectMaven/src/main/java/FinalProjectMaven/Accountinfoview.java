/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FinalProjectMaven;

/**
 *
 * @author dukei
 */
public class Accountinfoview extends View {

    Accountinfoview() {

    }

    @Override
    public String makeHTML() {

        String html = "<html><body>";
        html += "Account Info (Username here)<br>"
                + "Account Number: "
                + "(Account Number here)<br>"
                + "Account Name: "
                + "(Account Name here)<br>";

        html += "</body></html>";

        return html;

    }

}
