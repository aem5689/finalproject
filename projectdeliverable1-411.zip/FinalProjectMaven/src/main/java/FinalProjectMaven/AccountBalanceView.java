/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FinalProjectMaven;

/**
 *
 * @author dukei
 */
public class AccountBalanceView extends View {

    AccountBalanceView() {

    }

    @Override
    public String makeHTML() {

        String html = "<html><body>";
        html += "Account Balance<br>"
                + "Account Number: "
                + "(Account Number here)<br>"
                + "Account Balance: "
                + "(Account Balance here)<br>";

        html += "</body></html>";

        return html;

    }

}
