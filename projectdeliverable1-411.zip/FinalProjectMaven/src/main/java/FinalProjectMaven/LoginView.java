/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FinalProjectMaven;

/**
 *
 * @author dukei
 */
public class LoginView extends View {

    @Override
    public String makeHTML() {
       
        String html = "<html><body>";
        //model here
       // if (am == null) {
            html += "<form>Please Enter Login Info:<br>"
                    + "Username: <input type='text' name='username'><br>"
                    + "Password: <input type='text' name='password'><br>"
                    + "<input type='submit' value='Submit'><br>"
                    + "</form>";
     /*   } else {
            html += String.format("<span style='color:red;'>There was an error in the form!</span><br><form>"
                    + "Name: <input type='text' value='%s' name='name'><br>"
                    + "Street: <input type='text' value='%s' name='street'><br>"
                    + "State: <input type='text' value='%s' name='state'><br>"
                    + "Zip: <input type='text' value='%s' name='zip'><br>"
                    + "<input type='submit' value='Submit'><br>"
                    + "</form>",
                    am.name, am.street, am.state, am.zipCode);
        } */

        html += "</body></html>";

        return html;
    }
    
}
