/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FinalProjectMaven;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class HttpRequest {

    String type; 
    String protocol;  
    String url; 
    String location;  
    Map<String, String> params;

    static HttpRequest fromString(String incomingRequestString) {

        String[] components = incomingRequestString.split(" ");

        if (components.length!=3)
        {
            return null;
        }
        HttpRequest req = new HttpRequest();

        req.type = components[0];
        if (! req.type.equals("GET"))
        {
            return null;
        }
        req.protocol = components[2];
        req.url = components[1];
        req.params = new HashMap<String, String>();
        if (req.url.contains("?")) {

            req.location = req.url.substring(0, req.url.indexOf("?"));
            String params = req.url.substring(req.url.indexOf("?") + 1);
            
            for (String pair : params.split("&")) {
                String[] keyVal = pair.split("=");
                if (keyVal.length == 2) {
                    req.params.put(keyVal[0], keyVal[1]);
                }
            }

        } else {
            req.location = req.url;
        }
        return req;
    }
}

