/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FinalProjectMaven;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.text.View;

public class HttpServerRedux {
    
    public HttpServerRedux () {
    }
  
    public static void main(String[] args) {

        HttpServerRedux server = new HttpServerRedux();
        
        try (ServerSocket serverSocket = new ServerSocket(12345)) {
            System.out.println("Waiting for connection.....");

            server.serverEventLoop(serverSocket);

        } catch (IOException ex) {
            System.out.println("exception occurred in high-level event loop.  terminating.");
        }

    }

    private  void serverEventLoop(ServerSocket serverSocket) throws IOException {

        while (true) {
            System.out.println("Event loop - waiting");

            Socket connectionSocket = serverSocket.accept();
            System.out.println("Incoming connection");

            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(
                            connectionSocket.getInputStream()));
                    PrintWriter out = new PrintWriter(
                            connectionSocket.getOutputStream(), true)) {

                handleIncomingTcpConnection(br, out);
                out.close();
                
            } catch (IOException ex) {
                System.out.println("exception during creation of streams.");
            }
            connectionSocket.close();
        }

    }

    private void handleIncomingTcpConnection(BufferedReader br, PrintWriter out) throws IOException {

        TransactionController controller = new TransactionController();
        
        while (true) {
            String inputLine = br.readLine();

            if (inputLine == null) {
                break;
            }

            HttpRequest req = HttpRequest.fromString(inputLine);

            if (req != null) {
                System.out.println("Parsed: " + inputLine);
                FinalProjectMaven.View v = controller.respondToLocationRequest(req);

                out.write("HTTP/1.1 ");
                if (v.isOKStatus()) {
                    out.write("200 OK\n");
                } else {
                    out.write("404 Not Found\n");
                }
                out.write("Content-Type: text/html\n");
                out.write("\n");
                out.write(v.makeHTML());
                out.write("\n\n");
                System.out.println("Responded.");
                break;
            }
            

        }

    }

}
